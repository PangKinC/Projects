﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestaurantFinder.Models
{
    public class RestaurantReview
    {
        public int ID { get; set; }
        public int RestaurantID { get; set; }
        public string Review { get; set; }
        public virtual RestaurantDetail Restaurants { get; set; }
    }
}