﻿using RestaurantFinder.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace RestaurantFinder.Controllers
{
    public class HomeController : Controller
    {

        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Home
        public ActionResult AdminTools()
        {
            RestaurantView resView = new RestaurantView(); 
            resView.allRes = (from r in db.Restaurants select r).ToList();
            resView.allRev = (from t in db.Reviews select t).ToList();

            return View(resView);
        }

        public ActionResult Home()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Home(string address)
        {
            if (string.IsNullOrEmpty(address)) { return View(); }

            var matchFound = GoogleMapsAPIHelpersCS.GetGeocodingSearchResults(address);
            var matchCount = matchFound.Elements("result").Count();

            if (matchCount == 0) {
                ViewData["NoMatch"] = true;
                return View();
            }
            else if (matchCount == 1) {
                return RedirectToAction("AddressResult", new { Address = matchFound.Element("result").Element("formatted_address").Value });
            }
            else {
                var matchList = from match in matchFound.Elements("result")
                                let formatted_address = match.Element("formatted_address")
                                .Value
                                select formatted_address;
                ViewData["MatchResults"] = matchList;

                return View();
            }

        }

        public ActionResult AddressResult(string address)
        {
            if (string.IsNullOrEmpty(address)) { return RedirectToAction("Home"); }

            var matchFound = GoogleMapsAPIHelpersCS.GetGeocodingSearchResults(address);
            var ltde = Convert.ToDecimal(matchFound.Element("result").Element("geometry").Element("location").Element("lat").Value, NumberFormatInfo.InvariantInfo);
            var lgte = Convert.ToDecimal(matchFound.Element("result").Element("geometry").Element("location").Element("lng").Value, NumberFormatInfo.InvariantInfo);

            var nearbyRes = from r in db.Restaurants
                            where Math.Abs(r.Latitude - ltde) < 0.25M &&
                            Math.Abs(r.Longitude - lgte) < 0.25M
                            select new SortLocations()
                            {
                                ID = r.ID,
                                Name = r.Name,
                                Cuisine = r.Cuisine,
                                Address = r.Address,
                                Area = r.Area,
                                City = r.City,
                                Country = r.Country,
                                Postcode = r.Postcode,
                                PhoneNumber = r.PhoneNumber,
                                PriceRange = r.PriceRange,         
                                Latitude = r.Latitude,
                                Longitude = r.Longitude,
                                AddressLatitude = ltde,
                                AddressLongitude = lgte
                            };

            var sortedRes = nearbyRes.ToList().OrderBy(r => r.AddressDistance).ToList();
            return View(sortedRes);
        }

        public ActionResult CreateData()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateData(RestaurantDetail res)
        {
            if (ModelState.IsValid) {
                db.Restaurants.Add(res);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else { return View(res); }
        }

        public ActionResult ReadData(int? id)
        {
            RestaurantDetail res = db.Restaurants.Find(id);
            return View(res);
        }

        public ActionResult UpdateData(int? id)
        {
            RestaurantDetail res = db.Restaurants.Find(id);
            return View(res);
        }

        [HttpPost]
        public ActionResult UpdateData(RestaurantDetail res)
        {
            if (ModelState.IsValid) {
                db.Entry(res).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else { return View(res); }
        }

        public ActionResult DeleteData(int? id)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            RestaurantDetail res = db.Restaurants.Find(id);
            if (res == null) { return HttpNotFound(); }
            return View(res);
        }

        [HttpPost, ActionName("DeleteData")]
        public ActionResult DeleteConfirmation(int? id)
        {
            RestaurantReview rev = db.Reviews.Find(id);
            if (rev != null) { db.Reviews.Remove(rev); }

            RestaurantDetail res = db.Restaurants.Find(id);
            db.Restaurants.Remove(res);

            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult RCReview(int id)
        {
            /*var rate = db.Rates.Where(r => r.Restaurant_ID == id);
            R
            return View(rate);*/       
            RestaurantReview rev = new RestaurantReview();
            RestaurantDetail res = db.Restaurants.Find(id);
            RestaurantView rv = new RestaurantView();
            rv.rev = rev;
            rv.res = res;
            return View(rv);
        }

        [HttpPost]
        public ActionResult RCReview(RestaurantView rv)
        {
            if (ModelState.IsValid)
            {
                RestaurantReview rev = new RestaurantReview();
                rev.Review = rv.rev.Review;
                rev.RestaurantID = rv.res.ID;

                db.Reviews.Add(rev);
                db.SaveChanges();
                return View(rv);
            }
            else { return View(rv); }
        }

        public ViewResult ReviewList(int id)
        {
            /*SpecificReview reviews = new SpecificReview { checkReview = db.Rates.Where(r => r.Restaurant_ID == id).OrderBy(p => p.ID) };

            return PartialView(reviews);*/

            //return PartialView(db.Rates.ToList());

           return View(db.Reviews.Where
                (r => r.RestaurantID == id)
                .OrderByDescending(p => p.ID).
                ToList());
        }

        public ActionResult DeleteReview(int? id)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            RestaurantReview rev = db.Reviews.Find(id);
            if (rev == null) { return HttpNotFound(); }
            return View(rev);
        }

        [HttpPost, ActionName("DeleteReview")]
        public ActionResult DeleteReviewC(int? id)
        {
            RestaurantReview rev = db.Reviews.Find(id);
            db.Reviews.Remove(rev);

            db.SaveChanges();
            return RedirectToAction("Index");
        }
        
    }
}